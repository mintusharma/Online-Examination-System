
package com.oes.dao;
import java.sql.*;
import com.oes.bean.Records;
import java.util.List;

public class RecordDAO {
      public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stud", "", "");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }
      
      public static int insertStudentRecord(Records r){
          int status=0;
          try {
               Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stud", "root", "root");
            PreparedStatement ps = con.prepareStatement(
                    "insert into studregistration values (?,?,?,?,?,?,?,?,?)"
            );
            ps.setString(1, r.getFname());
            ps.setString(2, r.getLname());
            ps.setString(3, r.getEmailid());
            ps.setString(4, r.getPassword());
            ps.setString(5, r.getAddress());
            ps.setInt(6, r.getAge());
            ps.setString(7, r.getGender());
            ps.setString(8, r.getCourse());
            ps.setInt(9, r.getId());
            status = ps.executeUpdate();
          } catch (Exception e) {
          }
          return status;
      }
      
      
      public static int insertFacultyRecord(Records r){
          int status=0;
          try {
               Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stud", "root", "root");
            PreparedStatement ps = con.prepareStatement(
                    "insert into facultyregistration values (?,?,?,?,?,?,?,?,?,?,?)"
            );
            ps.setString(1, r.getFname());
            ps.setString(2, r.getLname());
            ps.setString(3, r.getEmailid());
            ps.setString(4, r.getPassword());
            ps.setString(5, r.getAddress());
            ps.setString(11, r.getDate());
            ps.setString(6, r.getGender());
            ps.setString(7, r.getQualification());
            ps.setInt(8, r.getExperience());
            ps.setInt(9,r.getAge());
            ps.setString(10, r.getUsername());
            status = ps.executeUpdate();
          } catch (Exception e) {
          }
          return status;
          
      }
      public static Records getRecordById(String fname){  
    Records u=null;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("select * from studregistration where fname=?");  
        ps.setString(1,fname);  
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            u=new Records();  
            u.setId(rs.getInt("id"));  
            u.setFname(rs.getString("fname"));
            u.setLname(rs.getString("lname"));
            u.setEmailid(rs.getString("emailid"));
            u.setPassword(rs.getString("password"));  
            u.setAddress(rs.getString("address"));  
            u.setAge(rs.getInt("age"));  
            u.setGender(rs.getString("gender"));
            u.setCourse(rs.getString("course"));
        }  
    }catch(Exception e){System.out.println(e);}  
    return u;  
}  
      
}
